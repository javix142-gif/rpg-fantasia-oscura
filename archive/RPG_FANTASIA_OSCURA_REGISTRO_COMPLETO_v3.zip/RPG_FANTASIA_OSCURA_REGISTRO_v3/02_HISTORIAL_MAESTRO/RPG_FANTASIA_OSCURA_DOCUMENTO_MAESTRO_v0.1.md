# DOCUMENTO MAESTRO DE DISEÑO — RPG DE FANTASÍA OSCURA

## Estado del documento

**Versión:** 0.1  
**Estado:** Diseño conceptual consolidado  
**Objetivo:** Reunir en un único documento todas las decisiones tomadas hasta ahora para el videojuego, evitando contradicciones y separando claramente lo definido de lo pendiente.  
**Plataforma principal:** Android  
**Formato de juego:** RPG offline, horizontal, con exploración isométrica/top-down y estética 2.5D pixel art moderna.

---

# 1. Visión general del juego

El proyecto será un RPG de fantasía clásica con elementos de fantasía oscura, melancólica y decadente.

El mundo debe comenzar con una sensación relativamente luminosa, heroica y reconocible: pueblos prósperos, caminos transitados, mercados, castillos, iglesias, gremios y paisajes agradables. Sin embargo, a medida que el jugador avanza, determinadas regiones, personas, instituciones y acontecimientos revelan una corrupción mucho más profunda.

La intención no es construir un mundo permanentemente oscuro, sino uno capaz de pasar de momentos alegres y esperanzadores a otros de horror, decadencia y desesperanza.

El juego debe conservar una sensación clásica en exploración, clases, progresión, magia, equipamiento, mazmorras, enemigos y estructura general, pero incorporar giros narrativos y sistémicos que lo diferencien.

La principal idea diferencial es:

> El mundo posee una historia propia que avanza aunque el protagonista decida no participar activamente en ella.

El jugador puede convertirse en héroe, mercader, cazarrecompensas, miembro de una facción, gobernante, criminal, líder, oportunista, hechicero corrupto o incluso aspirar a convertirse en el nuevo Emperador Demonio.

---

# 2. Principios de diseño

## 2.1. Sensación general

- Fantasía heroica clásica como base.
- Fantasía oscura melancólica y decadente como contraste.
- Mundo duro, pero con esperanza.
- Algunas zonas pueden ser muy alegres, luminosas o acogedoras.
- Otras pueden ser horribles, corruptas, desesperanzadoras o violentas.
- El contraste entre ambos extremos es una parte fundamental de la identidad del juego.

## 2.2. Regla de diseño principal

Un sistema sólo debe recibir profundidad adicional si interactúa con al menos otros dos sistemas relevantes.

Ejemplos:

- Comercio interactúa con economía, guerra, reputación, recursos y política: merece profundidad.
- Facciones interactúan con misiones, clases, historia, reputación y política: merecen profundidad.
- Agricultura o decoración de casas tienen menor impacto sistémico: deben ser compactas o secundarias.

## 2.3. Filosofía narrativa

- No existe una barra simple de “bien” y “mal”.
- Una buena acción puede producir consecuencias negativas.
- Una acción egoísta puede producir beneficios colaterales.
- Las decisiones pueden favorecer a un reino, grupo o persona y perjudicar a otro.
- Las consecuencias pueden aparecer mucho después.
- No actuar también es una decisión.
- El mundo no espera al jugador.
- Las relaciones entre razas, religiones, clases sociales y subreinos son tensas, complejas y no siempre explícitas.

---

# 3. Mundo y contexto histórico

## 3.1. Estructura política

El antiguo gran reino o imperio se encuentra actualmente dividido en **cuatro subreinos**.

Estos subreinos mantienen conflictos derivados de:

- moralidad;
- filosofía;
- religión;
- poder;
- recursos;
- territorio;
- herencias históricas;
- legitimidad política.

Existen guerras civiles y conflictos entre antiguos territorios que previamente formaban parte de una misma estructura imperial.

## 3.2. Estado del mundo

A simple vista, especialmente en las grandes ciudades, existen señales de prosperidad y recuperación.

Sin embargo:

- existe un miedo permanente a los demonios;
- las guerras desgastan a los subreinos;
- algunas regiones muestran restos de una civilización más avanzada;
- existen señales de una antigua edad de gloria;
- determinadas zonas parecen haber retrocedido hacia una edad oscura;
- la corrupción comienza a manifestarse en personas, criaturas, ruinas e instituciones.

## 3.3. Amenaza demoníaca

El mundo se aproxima progresivamente a una invasión generalizada de demonios y criaturas no humanas o humanoides.

Uno de los grandes misterios es que:

> Los demonios no son una especie externa al mundo humano.

En realidad, los demonios se originan a partir de los propios humanos y humanoides mediante una enfermedad, maldición, corrupción o proceso todavía por definir con precisión.

## 3.4. Emperador Demonio

El Emperador Demonio actual es, en realidad:

> El primer Emperador del antiguo gran reino.

Este hecho forma parte del núcleo de los grandes giros narrativos.

## 3.5. Civilización perdida

En determinadas regiones deben existir restos de una civilización anterior más avanzada.

Estos restos deben generar:

- sensación de gloria pasada;
- dudas sobre la historia oficial;
- ruinas;
- tecnología o magia olvidada;
- objetos antiguos;
- evidencias contradictorias;
- secretos relacionados con el origen de la corrupción y los demonios.

---

# 4. Premisa inicial

El protagonista vive originalmente en un **pueblo pequeño y relativamente neutral**, ubicado en los alrededores de los grandes territorios.

Es una persona:

- conocida;
- apreciada por vecinos;
- querida por su familia;
- integrada a la comunidad.

El pueblo es atacado por una mezcla de:

- humanos;
- humanoides;
- criaturas demoníacas.

La causa aparente del ataque es la búsqueda de un objeto legendario:

> El Collar de los Cinco Divinos.

Se cree que este objeto posee la capacidad de controlar imperios, reinos o poderes relacionados con ellos.

La verdadera naturaleza del collar debe permanecer inicialmente ambigua.

Diferentes grupos pueden creer que:

- legitima el derecho al Imperio;
- permite controlar ejércitos;
- es una reliquia sagrada;
- permite controlar demonios;
- puede destruir demonios;
- permite controlar territorios;
- actúa como llave;
- es simplemente una leyenda.

No se ha definido todavía cuál será su función real.

---

# 5. Protagonista

## 5.1. Personalización

El jugador podrá elegir:

- nombre;
- apariencia;
- clase inicial.

El pasado del protagonista será relativamente definido.

El futuro del personaje dependerá de:

- decisiones;
- reputación;
- alianzas;
- acciones;
- corrupción;
- especialización;
- riqueza;
- posición política;
- relaciones con facciones.

## 5.2. Personalidad emergente

El personaje no tendrá una personalidad completamente fija.

La personalidad y moralidad se irán moldeando mediante:

- respuestas;
- decisiones;
- reputación;
- acciones públicas;
- acciones secretas;
- traiciones;
- alianzas;
- elecciones de poder;
- corrupción.

## 5.3. Motivación abierta

El juego no obligará al jugador a “salvar el mundo”.

El protagonista podrá orientarse hacia:

- venganza;
- exploración;
- riqueza;
- comercio;
- cazarrecompensas;
- poder político;
- liderazgo;
- unificación de los subreinos;
- búsqueda del collar;
- lucha contra los demonios;
- alianza con demonios;
- corrupción voluntaria;
- convertirse en demonio;
- convertirse en Emperador humano;
- convertirse en Emperador Demonio;
- escapar del continente;
- vivir como un personaje relativamente normal durante parte de la historia.

---

# 6. Historia y progresión del mundo

## 6.1. Historia global

La historia del mundo avanza de manera relativamente lineal en cuanto a:

- guerras;
- crisis políticas;
- conflictos religiosos;
- aumento de corrupción;
- aparición de demonios;
- invasión demoníaca.

El jugador puede alterar ciertos acontecimientos, pero no detener el paso de la historia simplemente ignorándola.

## 6.2. Consecuencia de no intervenir

Si el jugador no interviene de ninguna manera relevante:

- los conflictos continúan;
- los subreinos se debilitan;
- la corrupción aumenta;
- la amenaza demoníaca progresa;
- finalmente los demonios vencen;
- el Emperador Demonio triunfa.

El jugador puede morir como una persona más si no posee los medios para sobrevivir al colapso.

## 6.3. Sistema de estados del mundo

Se propone una estructura conceptual de progresión:

1. Paz frágil.
2. Conflictos fronterizos.
3. Primeras escaramuzas.
4. Guerra entre subreinos.
5. Crisis religiosa o política.
6. Expansión de corrupción.
7. Guerra generalizada.
8. Brotes demoníacos graves.
9. Colapso de regiones.
10. Invasión demoníaca.
11. Ascenso definitivo del Emperador Demonio si nadie lo detiene.

Este sistema no debe depender únicamente de tiempo real.

Debe avanzar mediante:

- viajes;
- descanso;
- misiones;
- decisiones;
- eventos;
- capítulos;
- hitos narrativos.

Explorar no debe castigar injustamente al jugador.

---

# 7. Estructura narrativa

## 7.1. Tipo de narrativa

- Historia global lineal.
- Rutas personales ramificadas.
- Decisiones importantes controladas.
- Consecuencias semipermanentes.
- Eventos que pueden reaparecer varias horas después.

## 7.2. Forma de contar la historia

Se priorizará:

- acción visual;
- escenas;
- acontecimientos;
- cambios ambientales;
- consecuencias visibles.

El diálogo debe ser:

- breve;
- preciso;
- elegante;
- significativo;
- filosófico sólo cuando tenga sentido.

No debe utilizarse diálogo extenso para explicar información que puede mostrarse visualmente.

El lore profundo será opcional.

El jugador podrá obtener más información mediante:

- preguntas opcionales;
- libros;
- documentos;
- ruinas;
- objetos;
- NPC;
- historiadores;
- descripciones;
- lugares secretos.

---

# 8. Grandes giros narrativos ya definidos

Se consideran parte del núcleo del juego:

1. El Emperador Demonio es el primer Emperador del antiguo reino.
2. Los demonios se originan a partir de humanos y humanoides.
3. La historia oficial del mundo contiene mentiras u omisiones.
4. Determinados héroes del pasado pueden haber terminado convertidos en monstruos.
5. Algunos enemigos pueden haber sido personas comunes.
6. Los humanos también son responsables del desastre.
7. El jugador puede contribuir al problema.
8. El antagonista o algunas facciones demoníacas pueden estar intentando evitar algo todavía peor.
9. El poder económico puede salvar al jugador, pero suele tener consecuencias sobre otros.
10. Buenas acciones pueden producir resultados negativos.
11. Aliados o personajes amigables pueden elegir finalmente a su pueblo, familia, religión o facción por sobre el protagonista.

---

# 9. Razas, discriminación y tensiones sociales

Las diferentes razas o especies no se llevarán necesariamente bien.

El racismo o discriminación debe mostrarse de manera principalmente indirecta:

- precios diferentes;
- sospecha;
- controles;
- restricciones;
- matrimonios mal vistos;
- bromas;
- comentarios;
- separación social;
- oportunidades bloqueadas;
- prejuicios institucionales.

No debe presentarse mediante exposición constante o caricaturas.

Deben existir contradicciones, excepciones y relaciones genuinas entre individuos.

---

# 10. Exploración y mapa

## 10.1. Estructura del mundo

- Cuatro grandes subreinos.
- Cuatro grandes ciudades principales.
- Pueblos medianos.
- Pueblos pequeños.
- Campamentos.
- Campamentos de bandidos.
- Campamentos de aventureros.
- Mazmorras.
- Ruinas.
- Zonas naturales.
- Regiones conectadas.

No será un mundo abierto continuo.

La prioridad será:

> densidad de contenido sobre distancia vacía.

## 10.2. Overworld

Se utilizará un overworld clásico transitable.

También existirá viaje automático cuando corresponda.

## 10.3. Movimiento

- Movimiento libre en ocho direcciones.
- Joystick virtual en móvil.
- Posible soporte de gamepad.

## 10.4. Enemigos

Los enemigos serán visibles en el mapa.

## 10.5. Mazmorras

- Laberintos moderados.
- Secretos.
- NPC ocultos.
- objetos ocultos.
- habitaciones secretas.
- bosses secretos.
- puzzles ambientales simples.

## 10.6. Interacción ambiental

El jugador podrá:

- examinar;
- mover;
- activar;
- abrir;
- interactuar con objetos.

## 10.7. Viaje rápido

Se desbloqueará progresivamente a medida que el jugador descubra regiones.

## 10.8. Día y noche

No se implementará inicialmente un ciclo continuo complejo.

Los cambios de día/noche serán principalmente narrativos o predefinidos.

## 10.9. Clima

El clima variará principalmente según región.

## 10.10. Eventos

Habrá:

- eventos guionados;
- eventos aleatorios;
- eventos condicionados por decisiones;
- eventos condicionados por reputación;
- eventos condicionados por estado del mundo.

## 10.11. Backtracking

Moderado.

Volver a zonas antiguas debe poder generar:

- nuevas recompensas;
- nuevos NPC;
- nuevos enemigos;
- cambios políticos;
- corrupción;
- nuevas rutas;
- secretos previamente inaccesibles.

---

# 11. Combate híbrido

El juego utilizará dos modalidades relacionadas entre sí.

## 11.1. Combate de exploración / farmeo

Inspiración general:

- ARPG;
- Zelda clásico.

Características:

- ocurre directamente en el mundo;
- combate rápido;
- enemigos comunes;
- ataques básicos;
- habilidades;
- drops;
- farmeo;
- encuentros cortos.

## 11.2. Combate importante

Duelos, enfrentamientos relevantes, bosses y situaciones narrativas importantes utilizarán:

- sistema ATB o turnos con timeline;
- escenario basado en el mismo lugar donde ocurre el enfrentamiento;
- mayor detalle táctico;
- cuadrícula táctica;
- posición;
- alcance;
- partes del cuerpo;
- comportamientos;
- patrones;
- debilidades;
- fases;
- puzzles de combate.

## 11.3. Grupo

Máximo:

**3 personajes.**

El jugador controla directamente sólo al protagonista.

Los compañeros se gestionan mediante IA, comportamiento o reglas por definir.

## 11.4. Timeline

- Timeline visible en combates tácticos.
- Elementos aleatorios en determinados encuentros de farmeo o iniciativa.

## 11.5. Recursos

- MP.
- Recursos particulares según clase.

## 11.6. Ataques y habilidades

- El ataque básico sigue siendo importante.
- Las habilidades dominan progresivamente el combate.

## 11.7. Elementos

Elementos principales:

- fuego;
- hielo;
- rayo;
- viento.

## 11.8. Estados alterados

Ejemplos:

- veneno;
- sueño;
- silencio;
- otros clásicos por definir.

## 11.9. Debilidades

Pueden depender de:

- elemento;
- tipo;
- estado;
- parte corporal;
- comportamiento;
- patrón.

## 11.10. Bosses

Los bosses deben tener:

- mecánicas propias;
- fases;
- patrones;
- puzzles de combate;
- partes vulnerables cuando corresponda.

## 11.11. QTE

Ocasionales.

No serán el centro del sistema de combate.

## 11.12. Velocidad de combate

Opciones:

- x1;
- x2;
- x3.

## 11.13. Auto-battle

Opcional contra enemigos triviales.

## 11.14. Escape

La probabilidad de escapar dependerá de estadísticas u otras condiciones.

## 11.15. Dificultad

Base:

- moderada clásica;
- posibilidad de dificultad alta y estratégica.

---

# 12. Clases base

Se fijan cinco clases base:

1. Guerrero.
2. Espadachín.
3. Arquero.
4. Hechicero.
5. Clérigo.

La clase inicial define:

- formación;
- estadísticas;
- habilidades;
- recursos;
- acceso inicial a determinadas ramas.

No determina de forma absoluta el futuro del personaje.

---

# 13. Especializaciones

## 13.1. Filosofía

Las especializaciones no se obtendrán simplemente por alcanzar un nivel.

Podrán desbloquearse mediante:

- maestros;
- academias;
- libros;
- misiones;
- facciones;
- dominio de armas;
- reliquias;
- eventos;
- pactos;
- corrupción;
- exploración.

## 13.2. Ejemplos provisionales

### Guerrero

- Caballero.
- Berserker.
- Soldado veterano.
- Guardián.
- Señor de la guerra.

### Espadachín

- Duelista.
- Maestro de armas.
- Espada rúnica.
- Asesino.
- Espada maldita.

### Arquero

- Cazador.
- Tirador.
- Explorador.
- Guardabosques.
- Cazador de monstruos.

### Hechicero

- Elementalista.
- Arcanista.
- Brujo.
- Nigromante.
- Mago de sangre.

### Clérigo

- Sacerdote.
- Paladín.
- Inquisidor.
- Sanador.
- Apóstata.

Estas especializaciones todavía son provisionales.

## 13.3. Requisitos y bloqueos

Algunas especializaciones pueden requerir:

- reputación;
- entrenamiento;
- dominio;
- determinada facción;
- estado narrativo;
- corrupción;
- decisiones previas.

Algunas rutas pueden bloquear otras.

Ejemplo:

Un Clérigo muy corrupto puede perder acceso a Paladín y abrir acceso a Apóstata.

## 13.4. Hibridación

Se permitirán determinados cruces entre ramas.

Ejemplos:

- Guerrero + magia → Espada rúnica.
- Arquero + cacería → Cazador de Demonios.
- Clérigo corrupto → Mago de Sangre o variante oscura.

No existirá libertad total.

---

# 14. Progresión de personaje

## 14.1. Nivel

EXP tradicional.

## 14.2. Estadísticas

- aumento automático;
- algunos puntos libres.

## 14.3. Habilidades

Se obtendrán mediante combinación de:

- nivel;
- árbol;
- armas;
- objetos;
- maestros;
- libros;
- misiones.

## 14.4. Árboles

Ramas relativamente pequeñas con decisiones significativas.

## 14.5. Respec

Posible, pero con coste.

---

# 15. Armas y dominio

Cualquier personaje podrá utilizar una variedad amplia de armas.

Sin embargo:

> No todos las utilizarán con la misma eficacia.

El dominio de arma aumentará mediante uso.

El dominio puede otorgar:

- precisión;
- daño;
- habilidades;
- bonificaciones;
- acceso a especializaciones.

---

# 16. Equipamiento y loot

## 16.1. Filosofía

Se priorizarán objetos manuales y reconocibles por sobre loot procedural masivo.

## 16.2. Rarezas

- común;
- raro;
- épico;
- legendario.

## 16.3. Slots

Entre 6 y 8 slots clásicos.

## 16.4. Mejora

Sistema de forja:

- +1 hasta +10.

## 16.5. Runas y gemas

Existirán sistemas simples de:

- runas;
- gemas;
- mejoras especiales.

## 16.6. Durabilidad

Sistema simple.

## 16.7. Inventario

Slots limitados.

## 16.8. Loot

- cofres;
- drops de enemigos.

## 16.9. Economía

- oro;
- materiales especiales.

## 16.10. Tiendas

Cada ciudad tendrá inventarios diferentes.

## 16.11. Crafting

Compacto:

- pociones;
- forja simple.

## 16.12. Objetos únicos

Existirán objetos únicos con lore, pero no en cantidades excesivas.

---

# 17. Magia

## 17.1. Naturaleza

La magia puede estar relacionada con:

- fuerzas prohibidas;
- pactos;
- sangre;
- religión;
- corrupción.

## 17.2. Escuelas principales iniciales

- luz;
- oscuridad.

Los elementos también participan del sistema de combate.

## 17.3. Coste

La magia normal utilizará principalmente MP.

La magia poderosa puede requerir además:

- HP;
- corrupción;
- objetos;
- pactos.

## 17.4. Aprendizaje

Se podrá aprender mediante:

- nivel;
- libros;
- maestros;
- progresión;
- skill tree;
- exploración.

## 17.5. Magia oscura

El jugador puede utilizarla.

Tendrá riesgos y consecuencias narrativas.

## 17.6. Invocaciones

Existirán algunas invocaciones especiales.

---

# 18. Corrupción

La corrupción es uno de los sistemas centrales del juego.

## 18.1. Principio

Debe ser útil.

Si sólo produce castigos, el jugador no tendrá razones para emplearla.

Puede otorgar:

- habilidades poderosas;
- acceso a rutas;
- acceso a magia;
- cambios de clase;
- ventajas de combate;
- interacción con demonios.

## 18.2. Consecuencias posibles

- sueños;
- cambios visuales;
- mutaciones;
- nuevas habilidades;
- cambios sociales;
- cambios de diálogo;
- pérdida de reputación;
- nuevas rutas;
- transformación demoníaca.

## 18.3. Interfaz

La corrupción puede afectar progresivamente:

- retrato;
- iconos;
- textos;
- efectos;
- música;
- interfaz;
- percepción del mundo.

Debe ser inquietante, no molesto.

---

# 19. Cordura, maldiciones y horror

Se han seleccionado como ideas relevantes:

- corrupción;
- cordura;
- maldiciones persistentes;
- magia peligrosa;
- objetos con historia;
- cambios del mundo;
- NPC que cambian;
- personajes que desaparecen;
- secretos históricos.

Su implementación exacta todavía debe definirse.

No todos tienen que convertirse en sistemas independientes.

Varios pueden integrarse dentro del sistema de corrupción, estado del mundo y narrativa.

---

# 20. Compañeros

## 20.1. Naturaleza

Los compañeros serán personajes únicos.

No serán simples slots de party.

## 20.2. Profundidad

Algunos tendrán:

- arcos propios;
- motivaciones;
- reputación;
- relaciones;
- decisiones;
- finales.

Muchos de sus arcos serán trágicos.

## 20.3. Permanencia

Los compañeros pueden:

- abandonar;
- traicionar;
- morir;
- convertirse en enemigos;
- convertirse en bosses;
- reaparecer posteriormente;
- alinearse con otra facción.

## 20.4. Relaciones

Las relaciones y romances serán secundarios.

No se construirá un simulador de vida o familia.

---

# 21. Misiones

## 21.1. Estructura

Historia principal:

- lineal ramificada;
- varias rutas.

Secundarias:

- mini historias;
- decisiones;
- algunas procedurales.

## 21.2. Tipos

- matar;
- buscar;
- investigar;
- explorar;
- conversar;
- escoltar;
- boss;
- puzzle;
- decisión moral;
- secreto.

## 21.3. Diálogos

- variedad de respuestas;
- elecciones relevantes;
- cambios según reputación;
- cambios según atributos;
- cambios según historia.

## 21.4. Skill checks

Algunas opciones dependerán de:

- atributos;
- conocimientos;
- reputación;
- clase;
- facción.

## 21.5. Misiones fallables

Algunas o muchas misiones pueden fallar.

## 21.6. Diario

Diario clásico con:

- objetivos;
- pistas;
- información importante.

---

# 22. Facciones y reputación

Se consideran uno de los sistemas secundarios de mayor prioridad.

## 22.1. Posibles grupos

- gremios de aventureros;
- mercaderes;
- iglesias;
- cazadores de demonios;
- ejércitos;
- criminales;
- contrabandistas;
- magos;
- cultos;
- nobles;
- facciones propias de cada subreino.

No todas tendrán la misma profundidad.

## 22.2. Reputación

La reputación se manejará por grupo.

Debe afectar:

- misiones;
- precios;
- acceso;
- información;
- especializaciones;
- alianzas;
- política;
- diálogo.

---

# 23. Moralidad, fama y consecuencias

No habrá barra bien/mal.

Se propone separar:

## Fama

Qué tan conocido es el protagonista.

## Reputación

Qué piensa cada facción o grupo.

## Afinidad

Qué piensa cada personaje importante.

## Historial

Registro real de decisiones y acciones.

Las acciones pueden ser:

- públicas;
- privadas;
- desconocidas;
- malinterpretadas.

---

# 24. Política

La política será relevante, pero compacta.

No se pretende crear un simulador de estrategia.

El jugador podrá ganar influencia mediante:

- reputación;
- riqueza;
- misiones;
- alianzas;
- secretos;
- apoyo militar;
- favores.

Posibles decisiones:

- apoyar herederos;
- financiar guerras;
- revelar escándalos;
- apoyar rebeliones;
- sabotear;
- asesinar;
- negociar;
- apoyar facciones.

---

# 25. Comercio y vida de mercader

El comercio será uno de los estilos de juego alternativos con mayor profundidad.

## 25.1. Sistema

- precios regionales;
- recursos regionales;
- escasez;
- rutas;
- contrabando;
- guerra;
- inversiones;
- propiedades;
- comercio entre subreinos.

## 25.2. Consecuencias

El comercio puede afectar:

- riqueza;
- política;
- guerra;
- abastecimiento;
- reputación;
- recursos.

Enriquecerse puede requerir decisiones moralmente cuestionables.

---

# 26. Cazarrecompensas

Sistema secundario de prioridad alta.

Puede incluir:

- contratos;
- objetivos;
- criminales;
- monstruos;
- demonios;
- recompensas;
- reputación.

Debe reutilizar sistemas existentes y no convertirse en otro juego independiente.

---

# 27. Propiedades, negocios y vida cotidiana

Sistemas secundarios compactos:

- comprar viviendas;
- comprar locales;
- negocios;
- ingresos pasivos;
- almacenamiento;
- mejoras simples.

No se priorizarán:

- decoración profunda;
- simulación de familia;
- agricultura compleja;
- crianza;
- simulación social exhaustiva.

---

# 28. Muerte y dificultad

## 28.1. Muerte

- regreso a último autosave o guardado;
- pérdida de oro;
- posible pérdida de EXP.

## 28.2. Curación

- posadas;
- pociones;
- magia.

## 28.3. Guardado

- autosave;
- guardado manual.

Frecuencia equilibrada.

## 28.4. Dificultad

- normal;
- difícil.

## 28.5. Escalado

Enemigos con escalado parcial.

No deben escalar completamente con el jugador.

## 28.6. Grinding

Opcional y moderado.

## 28.7. Supervivencia

Sólo algunos segmentos.

No será un survival permanente.

## 28.8. Lesiones

Estados temporales.

---

# 29. Dirección visual

## 29.1. Cámara

Mezcla:

- isométrica;
- top-down.

## 29.2. Tecnología

2.5D.

## 29.3. Estilo

Pixel art moderno inspirado en 16/32-bit.

## 29.4. Proporciones

Semi-realistas.

## 29.5. Paleta

Debe permitir extremos:

- colorida;
- luminosa;
- acogedora;
- oscura;
- corrupta;
- decadente.

## 29.6. Iluminación

2D dinámica moderada.

## 29.7. Retratos

Retratos para personajes importantes.

## 29.8. Animación

4–8 frames en animaciones clásicas, buscando fluidez.

## 29.9. Magia

Efectos claros y vistosos.

## 29.10. Violencia

Entre moderada y considerable.

Puede existir sangre, pero no se plantea gore extremo como eje central.

---

# 30. Dirección de audio

Pendiente de definir en detalle.

Se decidirá más adelante.

---

# 31. Plataforma y controles

## 31.1. Plataforma

Android.

## 31.2. Orientación

Horizontal.

## 31.3. Movimiento

Joystick virtual.

## 31.4. Interacción

Botón contextual.

## 31.5. Combate táctico

Grandes botones táctiles.

## 31.6. Sesiones

Debe sentirse como un RPG tradicional, pero permitir interrupciones frecuentes.

## 31.7. Autosave

Frecuencia media.

## 31.8. Offline

Completamente offline.

## 31.9. Cuenta

No se requiere cuenta.

## 31.10. Dispositivos

- celulares;
- tablets adaptables.

## 31.11. Gamepad

Opcional.

## 31.12. Rendimiento

Objetivo:

- 60 FPS cuando el dispositivo lo permita;
- modo o fallback de 30 FPS.

---

# 32. Rejugabilidad

Elementos seleccionados:

- misiones opcionales;
- builds distintas;
- decisiones alternativas;
- finales múltiples;
- bosses opcionales;
- superbosses;
- logros;
- bestiario;
- coleccionables;
- rutas de facciones.

---

# 33. Finales

Debe existir variedad de finales.

Ejemplos posibles:

- muerte común;
- muerte heroica;
- derrota durante la guerra;
- muerte por corrupción;
- huida;
- escape al Nuevo Mundo;
- supervivencia como mercader;
- victoria humana;
- reunificación de los subreinos;
- ascenso como líder;
- ascenso como rey;
- ascenso como nuevo Emperador;
- transformación demoníaca;
- ascenso como nuevo Emperador Demonio.

No todos están confirmados como finales definitivos.

---

# 34. Duración

Se considera cerrado:

## Historia crítica / rush

**5 a 8 horas.**

## Partida normal

**8 a 12 horas.**

## Partida amplia

**10 a 15 horas.**

## Contenido total

Puede superar las 15 horas si se intenta explorar gran parte del contenido.

## Filosofía

No será posible experimentar todo en una única partida.

La rejugabilidad dependerá de:

- rutas;
- especializaciones;
- facciones;
- builds;
- decisiones;
- finales.

---

# 35. Escala

Objetivo conceptual:

> RPG indie completo.

Sin embargo, el desarrollo debe comenzar con un vertical slice.

El vertical slice debe demostrar:

- exploración;
- combate;
- progresión;
- una región;
- un pueblo;
- una pequeña mazmorra;
- un boss;
- una decisión;
- una consecuencia;
- una especialización;
- inventario;
- guardado;
- funcionamiento móvil.

---

# 36. Prioridades de desarrollo conceptual

Orden aproximado de importancia:

1. Mundo y progresión histórica.
2. Exploración.
3. Combate.
4. Historia y decisiones.
5. Clases y builds.
6. Corrupción.
7. Facciones.
8. Compañeros.
9. Misiones.
10. Equipamiento.
11. Economía y comercio.
12. Política.
13. Cazarrecompensas.
14. Propiedades y negocios.
15. Relaciones.
16. Oficios secundarios.
17. Actividades menores.

---

# 37. Sistemas centrales

Se consideran actualmente como núcleo:

- progresión histórica del mundo;
- exploración;
- combate híbrido;
- clases;
- especializaciones;
- reputación;
- decisiones;
- corrupción;
- facciones;
- economía regional;
- consecuencias persistentes;
- múltiples finales.

---

# 38. Sistemas secundarios

Con implementación compacta:

- relaciones;
- romances;
- propiedades;
- negocios;
- oficios;
- crafting;
- supervivencia;
- familia;
- vivienda;
- actividades menores.

---

# 39. Riesgos principales

## 39.1. Exceso de alcance

El mayor riesgo es intentar construir:

- RPG;
- sandbox;
- life sim;
- economía;
- política;
- estrategia;
- survival;
- simulador social;

como sistemas completos independientes.

Mitigación:

- sistemas compactos;
- reutilización;
- priorización;
- profundidad sólo cuando hay interacción con otros sistemas.

## 39.2. Dos sistemas de combate

El combate ARPG y el combate táctico pueden duplicar trabajo.

Mitigación:

Ambos deben compartir un núcleo técnico común:

- actor;
- stats;
- equipo;
- habilidades;
- estados;
- daño;
- elementos.

## 39.3. Mundo reactivo

Registrar demasiadas consecuencias puede crecer rápidamente.

Mitigación:

- flags;
- estados de región;
- reputación;
- eventos;
- consecuencias agrupadas.

## 39.4. Variantes narrativas

No debe escribirse una campaña diferente para cada decisión.

Mitigación:

- puntos de convergencia;
- estados del mundo;
- eventos reutilizables;
- rutas principales limitadas;
- consecuencias emergentes.

---

# 40. Decisiones cerradas

Actualmente se consideran definidas:

- fantasía heroica + oscuridad melancólica;
- mundo luminoso y oscuro según zona;
- medieval europeo clásico;
- corrupción progresiva;
- cuatro subreinos;
- guerra civil;
- decadencia imperial;
- origen humano de los demonios;
- Emperador Demonio = primer Emperador;
- protagonista no elegido;
- origen en pueblo pequeño;
- Collar de los Cinco Divinos;
- personalización;
- cinco clases base;
- especializaciones obtenidas dentro del mundo;
- personalidad emergente;
- rutas de vida alternativas;
- mundo que avanza sin el jugador;
- reputación por grupos;
- consecuencias persistentes;
- narrativa visual;
- lore opcional;
- compañeros únicos;
- regiones conectadas;
- overworld;
- cuatro ciudades principales;
- enemigos visibles;
- mazmorras con secretos;
- viaje rápido progresivo;
- combate híbrido;
- grupo máximo de tres;
- elementos;
- estados alterados;
- bosses multifase;
- progresión por EXP;
- dominio de armas;
- objetos manuales;
- forja;
- runas;
- magia peligrosa;
- corrupción;
- facciones;
- política compacta;
- comercio regional;
- 2.5D;
- pixel art moderno;
- Android horizontal;
- offline;
- soporte adaptable;
- duración de 5–8 h rush y 10–15 h amplia.

---

# 41. Decisiones todavía pendientes

Deben definirse posteriormente:

1. Nombre del juego.
2. Nombre del mundo.
3. Nombre del antiguo Imperio.
4. Los cuatro subreinos.
5. Cultura de cada subreino.
6. Religiones.
7. Razas.
8. Facciones concretas.
9. Gobernantes.
10. Conflictos territoriales.
11. Economía por región.
12. Recursos.
13. Arquitectura.
14. Historia cronológica.
15. Naturaleza exacta del Collar de los Cinco Divinos.
16. Identidad exacta de los Cinco Divinos.
17. Causa exacta de la corrupción.
18. Naturaleza exacta del Emperador Demonio.
19. Sistema final de cordura.
20. Sistema final de maldiciones.
21. Árbol definitivo de especializaciones.
22. IA de compañeros.
23. Sistema exacto del combate táctico.
24. Sistema exacto de cuadrícula.
25. Sistema de partes corporales.
26. Reglas finales de comercio.
27. Rutas políticas.
28. Finales definitivos.
29. Dirección musical.
30. Diseño visual de interfaz.
31. Identidad visual de cada región.
32. Cantidad final de bosses.
33. Bestiario.
34. Sistema final de logros.
35. Nombre y función real de facciones.
36. Forma concreta en que el jugador puede convertirse en demonio.
37. Reglas exactas de corrupción.
38. Equilibrio de recursos.
39. Alcance final del vertical slice.

---

# 42. Próximo paso recomendado

Diseñar los **cuatro subreinos**.

Para cada uno definir:

- nombre;
- capital;
- geografía;
- clima;
- cultura;
- arquitectura;
- población;
- razas;
- religión;
- ideología;
- economía;
- recursos;
- ejército;
- gobernante;
- conflicto interno;
- facciones;
- relación con los otros tres;
- opinión sobre los demonios;
- relación con el antiguo Imperio;
- visión sobre el Collar;
- estado inicial;
- destino por defecto si el jugador no interviene;
- posibles desenlaces si el jugador sí interviene.

---

# 43. Uso futuro de este documento

Este archivo debe funcionar como fuente de continuidad.

Cuando se avance:

- actualizar decisiones cerradas;
- mover decisiones provisionales a definitivas cuando corresponda;
- agregar nombres finales;
- registrar contradicciones;
- registrar sistemas descartados;
- mantener una sección de pendientes;
- evitar reescribir toda la historia en cada sesión.

A medida que el diseño crezca, conviene separar este archivo en documentos más específicos:

- `WORLD.md`
- `STORY.md`
- `COMBAT.md`
- `CLASSES.md`
- `FACTIONS.md`
- `ECONOMY.md`
- `CORRUPTION.md`
- `ART_DIRECTION.md`
- `MOBILE_UI.md`
- `PROJECT_STATE.md`

Por ahora, este documento debe mantenerse como la fuente maestra consolidada.
