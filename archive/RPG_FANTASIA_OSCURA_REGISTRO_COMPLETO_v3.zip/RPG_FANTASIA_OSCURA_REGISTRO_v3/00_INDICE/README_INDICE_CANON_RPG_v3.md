# RPG FANTASÍA OSCURA — ÍNDICE DEL REGISTRO CANÓNICO v3

Este registro reúne el canon narrativo y la preproducción técnica actualmente consolidada.

## 01 — Canon vigente

1. `RPG_FANTASIA_OSCURA_DOCUMENTO_MAESTRO_v0.4.md`
   - Documento maestro general vigente.

2. `SUBREINOS_CUATRO_CANON_v1.md`
   - Aureval, Vesperia, Serath y Keldran.

3. `IMPERIO_CINCO_DIVINOS_CORRUPCION_CANON_v1.md`
   - Ilyrion, Cinco Divinos, Edran, Resonancia, AUREA, LUX, MOR, Vitae, NEXUS y origen real de la corrupción.

4. `CYRION_CANON_v1.md`
   - Cyrion imperial y actual, Atrios, Quinta Puerta, Profundidades, Ecos, bosses y rutas finales.

5. `HISTORIA_PRINCIPAL_CANON_v1.md`
   - Campaña principal completa desde Liria hasta Cyrion y los desenlaces.

6. `PREPRODUCCION_PUNTOS_01_14_CANON_v1.md`
   - Los 14 bloques consolidados:
     1. compañeros;
     2. mapa;
     3. main quests;
     4. secundarias;
     5. clases/builds;
     6. combate;
     7. bestiario;
     8. economía;
     9. reputación/facciones;
     10. corrupción;
     11. loot/crafting;
     12. UI/UX móvil;
     13. arquitectura técnica;
     14. vertical slice.

## 02 — Historial maestro

Se conservan para trazabilidad:

- `RPG_FANTASIA_OSCURA_DOCUMENTO_MAESTRO_v0.1.md`
- `RPG_FANTASIA_OSCURA_DOCUMENTO_MAESTRO_v0.2.md`
- `RPG_FANTASIA_OSCURA_DOCUMENTO_MAESTRO_v0.3.md`
- `RPG_FANTASIA_OSCURA_DOCUMENTO_MAESTRO_v0.4.md`

## Uso recomendado al iniciar implementación

1. Leer `PREPRODUCCION_PUNTOS_01_14_CANON_v1.md`.
2. Consultar el canon específico sólo cuando una tarea necesite historia, regiones, NPC, quests o lore.
3. No modificar decisiones canónicas sin una decisión explícita posterior.
4. Mantener balance numérico data-driven hasta playtesting.
5. Actualizar `PROJECT_STATE.md` cuando comience la implementación real.
6. Construir primero el vertical slice, sin ampliar el alcance.
